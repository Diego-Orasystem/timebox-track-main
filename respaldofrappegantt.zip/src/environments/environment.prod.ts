export const environment = {
  production: false,
  apiUrl: 'http://10.90.0.190:3000/api'
};
